#!/system/bin/sh
# post-fs-data: mask three baked system apps so user APKs can install/update

exec >/dev/null 2>&1

hide_dir() {
  T="$1"
  [ -e "$T" ] || return 0
  TMP="/dev/catmask_$(/system/bin/toybox md5sum "$T" | /system/bin/toybox awk '{print $1}')"
  /system/bin/mkdir -p "$TMP"
  /system/bin/mount -o bind "$TMP" "$T"
}

# exact paths from your dump — no wildcards, no extras
hide_dir /product/app/SpeechServicesByGoogle
hide_dir /system/app/Tt9
#hide_dir /product/app/LatinImeGoogleGo
hide_dir /product/priv-app/CarrierServices
hide_dir /product/app/Maps
hide_dir /product/app/CalculatorGoogle
hide_dir /product/app/DeskClockGoogle
hide_dir /product/app/GalleryGo
hide_dir /system/app/MessagesGo
hide_dir /system/app/BasicDreams
hide_dir /system/app/BluetoothMidiService
hide_dir /system/app/VoiceAccess
hide_dir /system/app/Traceur
hide_dir /system/app/Protips
hide_dir /system/priv-app/KikaInput
hide_dir /system/priv-app/OemConnectDiagnostics
hide_dir /system/priv-app/OemPrivacyPolicy
hide_dir /system/priv-app/T-Mobile_Diagnostics
hide_dir /product/priv-app/GmsCore
hide_dir /product/priv-app/GmsCoreGo
hide_dir /product/priv-app/GooglePartnerSetup
hide_dir /product/priv-app/GoogleRestore
hide_dir /product/priv-app/Phonesky
hide_dir /system/app/PartnerBookmarksProvider
hide_dir /system/priv-app/KikaInput
hide_dir /system/system_ext/app/AntHalService
hide_dir /system/system_ext/app/AutoTests
hide_dir /system/system_ext/app/ConfURIDialer
hide_dir /system/system_ext/app/remoteSimLockAuthentication
hide_dir /system/system_ext/app/remotesimlockservice
hide_dir /system/system_ext/priv-app/GoogleFeedback
hide_dir /system/system_ext/priv-app/GoogleOneTimeInitializer
hide_dir /system/system_ext/priv-app/GoogleServicesFramework
hide_dir /product/priv-app/AndroidAutoPrebuiltStub
hide_dir /system/system_ext/priv-app/SetupWizard
